/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercisiosem6;

/**
 *
 * @author Colorado
 */
public class Main {

    private static Interfaz interfaz;
    private static GestiodnDatos datos[];
    private static int contador;
    
    
    
    public static void main(String[] args) {
        interfaz = new Interfaz();
        datos = new GestiodnDatos[260];
        
        for (int i = 0; i < 260; i++) {
            datos[i] = new GestiodnDatos();
        }
        
        contador=0;
        interfaz.setVisible(true);
    }
    
    
    public static void consulta(String cod,String apell,String nom,String sex,String direc,String hosp,String consul,String medic,String fech){
        datos[contador].setCodPaciente(cod);
        datos[contador].setApellidos(apell);
        datos[contador].setNombres(nom);
        datos[contador].setSexo(sex);
        datos[contador].setDireccion(direc);
        datos[contador].setHospital(hosp);
        datos[contador].setConsulta(consul);
        datos[contador].setMedico(medic);
        datos[contador].setFecha(fech);
        
        contador++;
        
        
    }
    
    
    public static void guarda(String busqueda) {
        
        for (int j = 0; j < datos.length; j++) {
            if (datos[j].getNombres().equals(busqueda)) {
                interfaz.cargadatos(datos[j]);
            }
        }
        
    }
    
     public static void guarda1(String busqueda2) {
        
        for (int j = 0; j < datos.length; j++) {
            if (datos[j].getHospital().equals(busqueda2)) {
                interfaz.cargadatos2(datos[j]);
            }
        }
        
    }
     
      public static void guarda2(String busqueda3) {
        for (int j = 0; j < datos.length; j++) {
            if (datos[j].getMedico().equals(busqueda3)) {
                interfaz.cargadatos3(datos[j]);
            }
        }
        
    }

    
    
}
